#include "Initialize.h"

#include "Player/Player.h"
#include "Camera/CameraController.h"
#include "Graphics/Camera.h"
#include "Enemy/Enemy.h"
#include "Item/Item.h"
#include "Collision/Collider.h"
#include "Quest/QuestDatabase.h"
#include "Interaction/Chest.h"
#include "Interaction/Door.h"
#include "Interaction/NPC.h"
#include "Assets/AssetManager.h"
#include "Graphics/Model.h"
#include "Scene/Scene.h"
#include "Particles/ParticleEmitter.h"

#include <glm/vec3.hpp>
#include <glm/geometric.hpp>
#include <memory>
#include <random>
#include <string>
#include <vector>

void InitializeQuests()
{
    MiraGame::Quest dungeonKeyQuest;
    dungeonKeyQuest.name = "Find the Dungeon Key";
    dungeonKeyQuest.description = "Find the key that opens the dungeon door.";
    dungeonKeyQuest.requiredItem = "Dungeon Key";
    MiraGame::QuestDatabase::RegisterQuest(dungeonKeyQuest);
}

void InitializeEnvironment(MiraEngine::Scene& scene)
{
#if 0
    // Campfire: rising grey smoke with additive fire on top.
    const glm::vec3 campfirePosition(3.0f, 0.0f, 3.0f);

    MiraEngine::ParticleSettings smoke;
    smoke.spawnRate = 8.0f;
    smoke.minLifetime = 2.0f;
    smoke.maxLifetime = 3.5f;
    smoke.minVelocity = { -0.2f, 0.6f, -0.2f };
    smoke.maxVelocity = { 0.2f, 1.0f, 0.2f };
    smoke.gravity = { 0.0f, 0.2f, 0.0f };
    smoke.drag = 0.5f;
    smoke.startSize = 0.3f;
    smoke.endSize = 1.2f;
    smoke.startColor = { 0.3f, 0.3f, 0.3f, 0.5f };
    smoke.endColor = { 0.5f, 0.5f, 0.5f, 0.0f };

    MiraEngine::ParticleSettings fire;
    fire.spawnRate = 60.0f;
    fire.minLifetime = 0.5f;
    fire.maxLifetime = 1.0f;
    fire.minVelocity = { -0.2f, 1.0f, -0.2f };
    fire.maxVelocity = { 0.2f, 2.0f, 0.2f };
    fire.gravity = { 0.0f, 0.5f, 0.0f };  // hot air rises
    fire.startSize = 0.4f;
    fire.endSize = 0.1f;
    fire.startColor = { 1.0f, 0.7f, 0.2f, 1.0f };
    fire.endColor = { 1.0f, 0.1f, 0.0f, 0.0f };
    fire.blend = MiraEngine::ParticleBlend::Additive;

    // Smoke is added first so the fire draws over it.
    auto campfireSmoke = std::make_unique<MiraEngine::GameObject>("CampfireSmoke");
    campfireSmoke->GetTransform().SetPosition(campfirePosition);
    campfireSmoke->SetParticleEmitter(smoke);
    scene.AddObject(std::move(campfireSmoke));

    auto campfireFire = std::make_unique<MiraEngine::GameObject>("CampfireFire");
    campfireFire->GetTransform().SetPosition(campfirePosition);
    campfireFire->SetParticleEmitter(fire);
    scene.AddObject(std::move(campfireFire));
#endif

    // Ground: a 40x40 plane with a tiling PBR material (ambientCG Ground037, CC0)
    const std::string grassTextures = "Assets/Textures/Grass/Grass001_1K-JPG_";

    auto ground = std::make_unique<MiraEngine::GameObject>("Ground");
    ground->SetModel("Assets/Models/Environment/Ground.obj");
    ground->SetTexture(MiraEngine::TextureSlot::Color, grassTextures + "Color.jpg");
    ground->SetTexture(MiraEngine::TextureSlot::Normal, grassTextures + "NormalGL.jpg");
    ground->SetTexture(MiraEngine::TextureSlot::Occlusion, grassTextures + "AmbientOcclusion.jpg");
    scene.AddObject(std::move(ground));

    // Grass: scattered clumps, kept off the spots where gameplay happens
    const std::string grassFolder = "Assets/Models/Environment/Grass/";

    const std::vector<std::string> grassModels = {
        "GrassClumpGreenA", "GrassClumpGreenB",
        "GrassClumpMidA",   "GrassClumpMidB",
        "GrassPatchGreen",  "GrassPatchMid",
    };

    struct ClearZone
    {
        glm::vec3 center;
        float radius;
    };

    const std::vector<ClearZone> clearZones = {
        {{0.9f, 0.0f, -4.0f}, 1.5f},  // player start
        {{2.0f, 0.0f, 0.0f}, 0.8f},   // sword
        {{-2.0f, 0.0f, 3.0f}, 0.8f},  // potion
        {{-1.7f, 0.0f, 1.0f}, 0.8f},  // dungeon key
        {{1.1f, 0.0f, 12.0f}, 1.5f},  // chest
        {{1.5f, 0.0f, 3.0f}, 1.5f},   // door
        {{-3.3f, 0.0f, 2.0f}, 1.0f},  // elder
    };

    std::mt19937 rng(1234); // fixed seed: same layout every run
    std::uniform_real_distribution<float> position(-18.0f, 18.0f);
    std::uniform_real_distribution<float> angle(0.0f, 360.0f);
    std::uniform_real_distribution<float> size(0.8f, 1.4f);
    std::uniform_int_distribution<std::size_t> pick(0, grassModels.size() - 1);

    const int grassCount = 150;
    int placed = 0;

    while (placed < grassCount)
    {
        const glm::vec3 spot(position(rng), 0.0f, position(rng));

        bool blocked = false;
        for (const ClearZone& zone : clearZones)
        {
            if (glm::distance(spot, zone.center) < zone.radius)
            {
                blocked = true;
                break;
            }
        }

        if (blocked)
        {
            continue; // pick another spot
        }

        // Each variant uses the texture matching its name ("Mid" variants use the mid-green texture).
        const std::string variant = grassModels[pick(rng)];
        const std::string texture = variant.find("Mid") != std::string::npos ? "GrassMid.png" : "GrassGreen.png";

        auto grass = std::make_unique<MiraEngine::GameObject>("Grass");
        grass->SetModel(grassFolder + variant + ".obj");
        grass->SetTexture(MiraEngine::TextureSlot::Color, grassFolder + texture);
        grass->GetTransform().SetPosition(spot);
        grass->GetTransform().SetRotation(glm::vec3(0.0f, angle(rng), 0.0f));
        grass->GetTransform().SetScale(glm::vec3(size(rng)));
        scene.AddObject(std::move(grass));

        ++placed;
    }
}

MiraGame::Player& InitializePlayer(MiraEngine::Scene& scene)
{
    auto player = std::make_unique<MiraGame::Player>(scene);
    MiraGame::Player& result = *player;
    player->GetTransform().SetPosition(glm::vec3(0.886f, 0.0f, -3.98f));
    scene.AddObject(std::move(player));
    return result;
}

void InitializeEnemy(MiraEngine::Scene& scene, MiraGame::Player& player)
{
    auto enemy = std::make_unique<MiraGame::Enemy>(player, scene, glm::vec3(5.0f, 0.0f, 5.0f));
    scene.AddObject(std::move(enemy));
}

void InitializeInteractions(MiraEngine::Scene& scene)
{
    // Sword
    MiraGame::ItemData swordData;
    swordData.name = "Sword";
    swordData.type = MiraGame::ItemType::Weapon;
    swordData.damage = 20;
    auto sword = std::make_unique<MiraGame::Item>(swordData);
    auto swordModel = ("Assets/Models/Interactable/Sword/Sword.obj");
    sword->SetModel(swordModel);

    const std::string swordFolder = "Assets/Models/Interactable/Sword/";
    sword->SetTexture(MiraEngine::TextureSlot::Color, swordFolder + "all.001_Base_color.png");
    sword->SetTexture(MiraEngine::TextureSlot::Normal, swordFolder + "all.001_Normal_OpenGL.png");
    sword->SetTexture(MiraEngine::TextureSlot::Occlusion, swordFolder + "all.001_Mixed_AO.png");

    sword->GetTransform().SetRotation(glm::vec3(-90.0f, 0.0f, 0.0f));
    sword->GetTransform().SetScale(glm::vec3(0.1f));
    sword->GetTransform().SetPosition(glm::vec3(2.0f, 0.5f, 0.0f));
    scene.AddObject(std::move(sword));

    // Potion
    MiraGame::ItemData potionData;
    potionData.name = "Potion";
    potionData.type = MiraGame::ItemType::Consumable;
    potionData.healAmount = 30;
    auto potion = std::make_unique<MiraGame::Item>(potionData);
    potion->GetTransform().SetScale(glm::vec3(0.06f));
    potion->SetModel("Assets/Models/Interactable/Potion/potion.obj");

    const std::string potionFolder = "Assets/Models/Interactable/Potion/";
    potion->SetTexture(MiraEngine::TextureSlot::Color, potionFolder + "potion_lp2_DefaultMaterial_BaseColor.png");
    potion->SetTexture(MiraEngine::TextureSlot::Normal, potionFolder + "potion_lp2_DefaultMaterial_Normal.png");

    potion->GetTransform().SetPosition(glm::vec3(-2.0f, 0.5f, 3.0f));
    scene.AddObject(std::move(potion));

    // Dungeon Key
    MiraGame::ItemData dungeonKeyData;
    dungeonKeyData.name = "Dungeon Key";
    dungeonKeyData.type = MiraGame::ItemType::KeyItem;
    auto dungeonKey = std::make_unique<MiraGame::Item>(dungeonKeyData);
    dungeonKey->GetTransform().SetScale(glm::vec3(0.5f));
    dungeonKey->SetModel("Assets/Models/Interactable/Key/Key.fbx");

    const std::string keyFolder = "Assets/Models/Interactable/Key/";
    dungeonKey->SetTexture(MiraEngine::TextureSlot::Color, keyFolder + "Key2_albedo.jpeg");
    dungeonKey->SetTexture(MiraEngine::TextureSlot::Normal, keyFolder + "Key2_normal.png");
    dungeonKey->SetTexture(MiraEngine::TextureSlot::Occlusion, keyFolder + "Key2_AO.jpeg"); 
    dungeonKey->GetTransform().SetPosition(glm::vec3(-1.68f, 0.5f, 1.0f));

    scene.AddObject(std::move(dungeonKey));

    // Chest
    MiraGame::ItemData chestPotion;
    chestPotion.name = "Chest Potion";
    chestPotion.type = MiraGame::ItemType::Consumable;
    chestPotion.healAmount = 50;
    auto chest = std::make_unique<MiraGame::Chest>(chestPotion);
    chest->SetModel("Assets/Models/Interactable/Chest/Chest.obj");

    const std::string chestFolder = "Assets/Models/Interactable/Chest/";
    chest->SetTexture(MiraEngine::TextureSlot::Color, chestFolder + "BaseColor.png");

    chest->GetTransform().SetPosition(glm::vec3(1.07f, 0.5f, 12.0f));
    chest->GetTransform().SetRotation(glm::vec3(0.0f, 90.0f, 0.0f));
    chest->GetTransform().SetScale(glm::vec3(2.0f, 2.0f, 2.0f));
    scene.AddObject(std::move(chest));

    // Door
    auto door = std::make_unique<MiraGame::Door>("Dungeon Key");
    door->SetModel("Assets/Models/Interactable/Door/Door.fbx");
	door->SetTexture(MiraEngine::TextureSlot::Color, "Assets/Models/Interactable/Door/Door.png");
    door->GetTransform().SetPosition(glm::vec3(1.5f, 0.0f, 3.0f));
    door->GetTransform().SetRotation(glm::vec3(0.0f, 90.0f, 0.0f));
    door->GetTransform().SetScale(glm::vec3(0.005f, 0.005f, 0.005f));
    scene.AddObject(std::move(door));
}

void InitializeNPCs(MiraEngine::Scene& scene)
{
    MiraGame::Dialogue elderDialogue;
    elderDialogue.beforeQuest = { "Greetings, traveler.", "The dungeon lies beyond the locked door.",
                                 "Find the Dungeon Key and you may enter." };
    elderDialogue.questActive = { "Have you found the Dungeon Key yet?", "Search carefully. It must be nearby." };
    elderDialogue.questCompleted = { "Excellent. You found the Dungeon Key.", "The dungeon awaits you." };
    elderDialogue.questTurnedIn = { "Good luck in the dungeon." };

    auto npc = std::make_unique<MiraGame::NPC>("Village Elder", elderDialogue, "Find the Dungeon Key");

    npc->GetTransform().SetPosition(glm::vec3(-3.3f, 0.0f, 2.0f));
    scene.AddObject(std::move(npc));
}

void InitializeCollisionObjects(MiraEngine::Scene& scene)
{
    auto wall = std::make_unique<MiraEngine::GameObject>("Wall 1");
    wall->SetModel("Assets/Models/Collision/Wall/Wall.obj");
	wall->SetTexture(MiraEngine::TextureSlot::Color, "Assets/Models/Collision/Wall/tex_u1_v1_diffuse.jpg");
	wall->SetTexture(MiraEngine::TextureSlot::Normal, "Assets/Models/Collision/Wall/tex_u1_v1_normal.jpg");
    wall->SetCollider(MiraEngine::Collider::Box(glm::vec3(2.95f, 0.7f, 0.15f)));
    wall->GetTransform().SetPosition(glm::vec3(0.0f, 0.0f, 10.0f));
    wall->GetTransform().SetRotation(glm::vec3(0.0f, -90.0f, -5.0f));
    scene.AddObject(std::move(wall));
}

void InitializeCamera(MiraEngine::Scene& scene, MiraEngine::Camera& camera, MiraGame::Player& player)
{
    auto cameraController = std::make_unique<MiraGame::CameraController>(camera, player);
    scene.AddObject(std::move(cameraController));
}
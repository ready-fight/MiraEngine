#include "Scene/GameObject.h"
#include "Scene/Scene.h"
#include "Collision/Collider.h"
#include "Graphics/Model.h"
#include "Graphics/Material.h"
#include "Animation/Animator.h"
#include "Assets/AssetManager.h"
#include "Particles/ParticleEmitter.h"

namespace MiraEngine
{
	GameObject::GameObject(const std::string& name)
		: m_name(name)
	{
	}

	GameObject::~GameObject() = default;

	void GameObject::Update(float deltaTime) {}

	void GameObject::DrawUI() {}

	void GameObject::FadeIn(float deltaTime)
	{
		if (m_material.color.a == 1.0f)
		{
			return;
		}

		float alpha = m_material.color.a;
		alpha += m_fadeSpeed * deltaTime;
		alpha = std::min(alpha, 1.0f);
		m_material.color.a = alpha;
	}

	void GameObject::FadeOut(float deltaTime)
	{
		if (m_material.color.a == 0.0f)
		{
			return;
		}

		float alpha = m_material.color.a;
		alpha -= m_fadeSpeed * deltaTime;
		alpha = std::max(alpha, 0.0f);
		m_material.color.a = alpha;

		if (alpha == 0)
		{
			m_pendingDestroy = true;
		}
	}

	bool GameObject::IsPendingDestroy() const
	{
		return m_pendingDestroy;
	}

	Transform& GameObject::GetTransform()
	{
		return m_transform;
	}

	const Transform& GameObject::GetTransform() const
	{
		return m_transform;
	}

	const std::string& GameObject::GetName() const
	{
		return m_name;
	}

	void GameObject::SetCollider(const Collider& collider)
	{
		m_collider = collider;
	}

	void GameObject::RemoveCollider()
	{
		m_collider.reset();
	}

	Collider* GameObject::GetCollider()
	{
		return m_collider ? &*m_collider : nullptr;
	}

	const Collider* GameObject::GetCollider() const
	{
		return m_collider ? &*m_collider : nullptr;
	}

	void GameObject::SetName(const std::string& name)
	{
		m_name = name;
	}

	void GameObject::SetModel(const std::string& path)
	{
		std::shared_ptr<Model> model = AssetManager::LoadModel(path);

		if (!model) {
			return;
		}

		m_model = model;

		if (m_model->GetBoneCount() > 0)
		{
			if (!m_animator)
				m_animator = std::make_unique<Animator>(*m_model);
			else
				m_animator->SetModel(*m_model);
		}
	}

	void GameObject::SetTexture(TextureSlot slot, const std::string& path)
	{
		std::shared_ptr<Texture> texture = AssetManager::LoadTexture(path);
		TextureSet& textures = m_material.textures;

		switch (slot)
		{
		case TextureSlot::Color:     textures.color = texture; break;
		case TextureSlot::Normal:    textures.normal = texture; break;
		case TextureSlot::Occlusion: textures.occlusion = texture; break;
		case TextureSlot::Roughness: textures.roughness = texture; break;
		}
	}

	Model* GameObject::GetModel()
	{
		return m_model.get();
	}

	const Model* GameObject::GetModel() const
	{
		return m_model.get();
	}

	Animator* GameObject::GetAnimator()
	{
		return m_animator.get();
	}

	const Animator* GameObject::GetAnimator() const
	{
		return m_animator.get();
	}

	Material& GameObject::GetMaterial()
	{
		return m_material;
	}

	const Material& GameObject::GetMaterial() const
	{
		return m_material;
	}

	void GameObject::PlayAnimation(const std::string& name, bool looping)
	{
		if (m_animator)
		{
			m_animator->PlayAnimation(name, looping);
		}
	}

	void GameObject::SetParticleEmitter(const ParticleSettings& settings)
	{
		m_particleEmitter = std::make_unique<ParticleEmitter>(settings);
	}

	ParticleEmitter* GameObject::GetParticleEmitter()
	{
		return m_particleEmitter.get();
	}

	const ParticleEmitter* GameObject::GetParticleEmitter() const
	{
		return m_particleEmitter.get();
	}

	void GameObject::Destroy()
	{
		m_pendingDestroy = true;
	}
}
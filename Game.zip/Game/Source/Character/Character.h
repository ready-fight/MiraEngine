#pragma once

#include "Scene/GameObject.h"

#include <string>

namespace MiraGame
{
    class Character : public MiraEngine::GameObject
    {
    public:
        Character(const std::string& name, int maxHealth);
        void TakeDamage(int amount);
        void Heal(int amount);
        int GetHealth() const;
        int GetMaxHealth() const;
        bool IsDead() const;
        void FaceDirection(const glm::vec3& direction);
        glm::vec3 GetFacing() const;

    private:
        int m_maxHealth = 100;
        int m_health = 100;
    };
}
#include "Core/Application.h"
#include "Player/Player.h"

#include <memory>

int main()
{
    MiraEngine::Application application;

    auto player =
        std::make_unique<MiraGame::Player>();

    application.GetScene().AddObject(
        std::move(player)
    );

    application.Run();

    return 0;
}
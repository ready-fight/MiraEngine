#pragma once

#include "Scene/GameObject.h"



namespace MiraGame
{
    class Player : public MiraEngine::GameObject
    {
    public:
        Player();

        void Update(float deltaTime) override;

    private:
        float m_speed = 2.0f;
    };
}
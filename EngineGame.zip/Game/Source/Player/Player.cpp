#include "Player/Player.h"

#include "Core/Input.h"
#include "Scene/Transform.h"

#include "Assets/AssetManager.h"
#include "Animation/Animator.h"

#include <glm/geometric.hpp>
#include <glm/vec3.hpp>

namespace MiraGame
{
    Player::Player()
        : MiraEngine::GameObject("Player")
    {
        SetModel(
            MiraEngine::AssetManager::LoadModel(
                "Assets/Models/Capoeira.fbx"
            )
        );

        GetTransform().SetScale(
            glm::vec3(0.01f)
        );

        if (MiraEngine::Animator* animator = GetAnimator())
        {
            animator->PlayAnimation(0);
        }
    }

    void Player::Update(float deltaTime)
    {
        glm::vec3 movement(0.0f);

        if (MiraEngine::Input::IsKeyPressed(MiraEngine::Key::W))
        {
            movement.z += 1.0f;
        }

        if (MiraEngine::Input::IsKeyPressed(MiraEngine::Key::S))
        {
            movement.z -= 1.0f;
        }

        if (MiraEngine::Input::IsKeyPressed(MiraEngine::Key::A))
        {
            movement.x -= 1.0f;
        }

        if (MiraEngine::Input::IsKeyPressed(MiraEngine::Key::D))
        {
            movement.x += 1.0f;
        }

        if (glm::length(movement) > 0.0f)
        {
            movement = glm::normalize(movement);

            MiraEngine::Transform& transform = GetTransform();

            transform.SetPosition(
                transform.GetPosition() +
                movement * m_speed * deltaTime
            );
        }
    }
}
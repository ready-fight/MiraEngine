#include "Enemy/Enemy.h"
#include "Player/Player.h"

#include "Animation/Animation.h"
#include "Animation/Animator.h"
#include "Assets/AssetManager.h"
#include "Collision/SphereCollider.h"
#include "Graphics/Model.h"
#include "Scene/Transform.h"

#include <glm/geometric.hpp>
#include <glm/vec3.hpp>

#include <cmath>
#include <iostream>

namespace MiraGame {
    Enemy::Enemy(Player* player, MiraEngine::Scene* scene)
        : Character("Enemy", 100), m_player(player), m_scene(scene) {
        auto model =
            MiraEngine::AssetManager::LoadModel("Assets/Models/Idle.fbx");

        SetModel(model);

        SetCollider(std::make_unique<MiraEngine::SphereCollider>(0.3f));

        GetTransform().SetScale(glm::vec3(0.01f));

        if (MiraEngine::Animator* animator = GetAnimator()) {
            animator->PlayAnimation("Idle");
        }
    }

    void Enemy::Update(float deltaTime) {
        if (IsDead()) {
            if (!m_hasDied) {
                if (MiraEngine::Animator* animator = GetAnimator()) {
                    animator->PlayAnimation("Death", false); // Death
                }

                m_hasDied = true;
            }

            return;
        }

        if (!m_player) {
            return;
        }

        MiraEngine::Transform& transform = GetTransform();

        if (!m_spawnPositionInitialized) {
            m_spawnPosition = transform.GetPosition();
            m_spawnPositionInitialized = true;
        }

        const glm::vec3 enemyPosition = transform.GetPosition();

        const glm::vec3 playerPosition = m_player->GetTransform().GetPosition();

        glm::vec3 direction = playerPosition - enemyPosition;

        direction.y = 0.0f;

        const float distance = glm::length(direction);

        const bool inDetectionRange = distance <= m_detectionRange;

        const bool inAttackRange = distance <= m_stopDistance;

        // Player is dead.
        if (m_player->IsDead()) {
            if (m_isMoving || m_isAttacking) {
                if (MiraEngine::Animator* animator = GetAnimator()) {
                    animator->PlayAnimation(0);
                }
            }

            m_isMoving = false;
            m_isAttacking = false;

            return;
        }

        // Player left detection range.
        // Return to spawn.
        if (!inDetectionRange) {
            m_isAttacking = false;
            m_attackTimer = 0.0f;
            m_attackTime = 0.0f;
            m_attackHitApplied = false;

            glm::vec3 returnDirection = m_spawnPosition - enemyPosition;

            returnDirection.y = 0.0f;

            const float spawnDistance = glm::length(returnDirection);

            if (spawnDistance > m_returnStopDistance) {
                if (!m_isMoving) {
                    if (MiraEngine::Animator* animator = GetAnimator()) {
                        animator->PlayAnimation("Walking");
                    }

                    m_isMoving = true;
                }

                returnDirection = glm::normalize(returnDirection);

                if (m_scene) {
                    m_scene->TryMove(*this,
                                     returnDirection * m_speed * deltaTime);
                }

                const float yaw =
                    std::atan2(returnDirection.x, returnDirection.z) * 180.0f /
                    3.14159265f;

                glm::vec3 rotation = transform.GetRotation();

                rotation.y = yaw;

                transform.SetRotation(rotation);

                return;
            }

            // Reached spawn.
            if (m_isMoving) {
                if (MiraEngine::Animator* animator = GetAnimator()) {
                    animator->PlayAnimation("Idle");
                }

                m_isMoving = false;
            }

            return;
        }

        // Chase Player.
        if (!inAttackRange) {
            if (!m_isMoving) {
                if (MiraEngine::Animator* animator = GetAnimator()) {
                    animator->PlayAnimation("Walking");
                }

                m_isMoving = true;
            }

            // Cancel an attack if Player moved away.
            m_isAttacking = false;
            m_attackTime = 0.0f;
            m_attackHitApplied = false;
            m_attackTimer = 0.0f;

            if (distance > 0.0f) {
                direction = glm::normalize(direction);

                if (m_scene) {
                    m_scene->TryMove(*this, direction * m_speed * deltaTime);
                }

                const float yaw =
                    std::atan2(direction.x, direction.z) * 180.0f / 3.14159265f;

                glm::vec3 rotation = transform.GetRotation();

                rotation.y = yaw;

                transform.SetRotation(rotation);
            }

            return;
        }

        // Close enough to attack.
        if (m_isMoving) {
            if (MiraEngine::Animator* animator = GetAnimator()) {
                animator->PlayAnimation("Idle");
            }

            m_isMoving = false;
        }

        if (m_isAttacking) {
            m_attackTime += deltaTime;

            if (!m_attackHitApplied && m_attackTime >= m_attackHitTime) {
                m_player->TakeDamage(m_attackDamage);

                std::cout << "Player HP: " << m_player->GetHealth() << "/"
                          << m_player->GetMaxHealth() << "\n";

                m_attackHitApplied = true;
            }

            if (m_attackTime >= m_attackDuration) {
                m_isAttacking = false;

                if (MiraEngine::Animator* animator = GetAnimator()) {
                    animator->PlayAnimation("Idle");
                }
            }

            return;
        }

        m_attackTimer += deltaTime;

        if (m_attackTimer >= m_attackCooldown) {
            m_attackTimer = 0.0f;
            m_attackTime = 0.0f;
            m_attackHitApplied = false;
            m_isAttacking = true;

            if (MiraEngine::Animator* animator = GetAnimator()) {
                animator->PlayAnimation("Attack", false);
            }
        }
    }
}